﻿using MyGame;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace JumpGame
{
    /// <summary>
    /// ReStart
    /// </summary>
    public class ReStart : MonoBehaviour
    {
        [HideInInspector]
        public bool IsStart = false;

        public GenerateWall WallManger;
        public PlayerController Player;
        public WallController Wall;
        public GameObject GameoverUI;
        public GameObject StartUI;

        private void Update()
        {
            IfGameOver();
        }

        public void StartButton()
        {
            IsStart = true;
            ReStartAll();
            Player.gameObject.SetActive(true);
            StartUI.SetActive(false);
        }

        public void ReStartButton()
        {
            ReStartAll();
            GameoverUI.SetActive(false);
        }

        private void StopAll()
        {
            foreach (var item in WallManger.Walls)
            {
                item.GetComponent<WallController>().MoveSpeed = 0;
            }
            foreach (var item in GameObject.FindGameObjectsWithTag("Drumstick"))
            {
                item.GetComponent<DrumstickController>().MoveSpeed = 0;
            }
        }

        private void ReStartAll()
        {
            Player.IsGameOver = false;
            Player.Score = 0;

            //Wall
            foreach (var item in WallManger.Walls)
            {
                item.GetComponent<WallController>().MoveSpeed = Wall.MoveSpeed;
                item.position = item.GetComponent<WallController>().OriginalLocation;
            }
            WallManger.Last = WallManger.Walls[WallManger.Walls.Length - 1];

            //Drumstick
            foreach (var item in GameObject.FindGameObjectsWithTag("Drumstick"))
            {
                DrumstickPool.Intance.RecoveryDrumstick(item);
            }

            //Player
            Player.transform.position = Vector3.left * 2;
        }

        private void IfGameOver()
        {
            if (Player.IsGameOver)
            {
                StopAll();

                if (IsStart)
                {
                    GameoverUI.SetActive(true);
                }
            }
        }


    }
}
